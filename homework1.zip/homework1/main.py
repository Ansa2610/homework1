a = 'Конституция'
print(a[0])
print(a[-1])
print(a[4:])
print(a[::-1])
print(a[1:11:2])